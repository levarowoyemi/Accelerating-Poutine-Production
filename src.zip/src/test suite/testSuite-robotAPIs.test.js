import axios from "axios";

// Original functions are commented out,
// then test function is written, immediately after.

// =================================================

// function OutremonaAPI() {
//   axios.get("https://api.jsonserve.com/R9AiIw").then(function (response) {
//     // handle success
//     const outremonaTask = response.data.Robot.Outremona.task;
//     return outremonaTask;
//   });
// }
test("Outremona: Robot, squeezing cheese task.", () => {
  return axios.get("https://api.jsonserve.com/R9AiIw").then((response) => {
    expect(response.data.Robot.Outremona.task).toBe("squeezing cheese...");
  });
});

// -----------------------------------------------------------------------------

// function MontroyashiAPI() {
//   axios
//     .get("https://api.jsonserve.com/R9AiIw")
//     .then(function (response) {
//       // handle success
//       console.log(response.data.Robot.Montroyashi);
//       const MontroyashiTask = response.data.Robot.Montroyashi.task;
//       const MontroyashiSinging = response.data.Robot.Montroyashi.singing;
//       setTask(MontroyashiTask);
//       setSinging(MontroyashiSinging);
//     });
// }

test("Montroyashi: listen to robots' environments, display Leonard Cohen lyrics, detect drunk people.", () => {
  return axios.get("https://api.jsonserve.com/R9AiIw").then((response) => {
    expect(response.data.Robot.Montroyashi.task).toBe(
      "No drunk people detected."
    );
    expect(response.data.Robot.Montroyashi.singing).toBe(
      '🎵🎵 "I will not be held like a drunkard under the cold tap of facts" 🎵🎵'
    );
  });
});

// -----------------------------------------------------------------------------

// function VerdunyAPI() {
//   axios
//     .get("https://api.jsonserve.com/R9AiIw")
//     .then(function (response) {
//       // handle success
//       console.log(response);
//       const VerdunyTask = response.data.Robot.Verduny.task;
//       setTask(VerdunyTask);
//     })
//     .catch(function (error) {
//       // handle error
//       console.log(error);
//     });
// }
test("Verduny: cut potatoes in cubes, dip them in maple sirup", () => {
  return axios.get("https://api.jsonserve.com/R9AiIw").then((response) => {
    expect(response.data.Robot.Verduny.task).toBe(
      "finished cutting cubes, and already dipped in maple syrup."
    );
  });
});

// -----------------------------------------------------------------------------

// function NordoAPI() {
//   axios
//     .get("https://api.jsonserve.com/R9AiIw")
//     .then(function (response) {
//       // handle success
//       console.log(response);
//       const NordoTask = response.data.Robot.Nordo.task;
//       setTask(NordoTask);
//     })
//     .catch(function (error) {
//       // handle error
//       console.log(error);
//     });
// }
test("Nordo: boil potatoes and give their current softness level.", () => {
  return axios.get("https://api.jsonserve.com/R9AiIw").then((response) => {
    expect(response.data.Robot.Nordo.task).toBe(
      "Potatoes boiled, and are soft-ish now."
    );
  });
});

// -----------------------------------------------------------------------------

// function BizarAPI() {
//   axios
//     .get("https://api.jsonserve.com/R9AiIw")
//     .then(function (response) {
//       // handle success
//       console.log(response);
//       const BizarTask = response.data.Robot.Bizar.task;
//       setTask(BizarTask);
//     })
//     .catch(function (error) {
//       // handle error
//       console.log(error);
//     });
// }
test("Bizar: fry potatoes with multiple oil choices.", () => {
  return axios.get("https://api.jsonserve.com/R9AiIw").then((response) => {
    expect(response.data.Robot.Bizar.task).toBe("Potatoes have been fried.");
  });
});

// -----------------------------------------------------------------------------

// function OldoportoAPI() {
//   axios
//     .get("https://api.jsonserve.com/R9AiIw")
//     .then(function (response) {
//       // handle success
//       console.log(response);
//       const OldoportoTask = response.data.Robot.Oldoporto.task;
//       setTask(OldoportoTask);
//     })
//     .catch(function (error) {
//       // handle error
//       console.log(error);
//     });
// }
test("Oldoporto: keep things at a specific temperature in a pot.", () => {
  return axios.get("https://api.jsonserve.com/R9AiIw").then((response) => {
    expect(response.data.Robot.Oldoporto.task).toBe(
      "keeping the pot at the exact temperature..."
    );
  });
});

// -----------------------------------------------------------------------------

// function PierreAPI() {
//   axios
//     .get("https://api.jsonserve.com/R9AiIw")
//     .then(function (response) {
//       // handle success
//       console.log(response);
//       const PierreTask = response.data.Robot.Pierre.task;
//       setTask(PierreTask);
//     })
//     .catch(function (error) {
//       // handle error
//       console.log(error);
//     });
// }
test("Pierre: mix ingredient in a cardboard, allow the box to be sent to needy user.", () => {
  return axios.get("https://api.jsonserve.com/R9AiIw").then((response) => {
    expect(response.data.Robot.Pierre.task).toBe(
      "Mixing ingredients in cardboard and sending to user now."
    );
  });
});
