import { gsap } from "gsap";
import { TextPlugin } from "gsap/TextPlugin";
import React, { useRef, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const verduny = {
  backgroundImage: 'url("/images/verduny.png")',
  height: "250px",
  width: "200",
};
const dip = {
  backgroundImage: 'url("/images/dip.png")',
  height: "100px",
  // width: "200",
};
gsap.registerPlugin(TextPlugin); // registers text-typing animation plugin.

function Verduny() {
  const app = useRef(null); // selects header dom element
  const title = useRef(null); // selects header dom element
  const typing = useRef(null); // selects header dom element
  const robot = useRef(null); // selects header dom element
  const cheese = useRef(null); // selects header dom element
  const button = useRef(null); // selects header dom element
  // Declare a new state variable, which we'll call "clicked"
  const [clicked, setClicked] = useState(false);
  const [task, setTask] = useState("");

  // animations - manual DOM manipulations
  useEffect(() => {
    gsap.from(app.current, { opacity: 0, duration: 1 });
    gsap.from(title.current, {
      scale: 100,
      opacity: 0,
      delay: 1,
    });
    gsap.from(robot.current, { scale: 0, opacity: 0, delay: 2, ease: "back" });
    gsap.from(cheese.current, {
      y: -100,
      opacity: 0,
      delay: 3,
      ease: "bounce",
    });

    gsap.to(typing.current, {
      text: "Hi, I'm Verduny. I'll be cutting the potatoes into cubes, and dipping them in maple syrup! Click the pot below. Then click Next.",
      delay: 5,
      duration: 4,
      ease: "none",
    });
    gsap.from(button.current, {
      scale: 0,
      opacity: 0,
      delay: 10,
      duration: 2,
      ease: "back",
    });

    VerdunyAPI();
  }, [title]);

    function VerdunyAPI() {
      axios
        .get("https://api.jsonserve.com/R9AiIw")
        .then(function (response) {
          // handle success
          console.log(response);
          const VerdunyTask = response.data.Robot.Verduny.task;
          setTask(VerdunyTask);
        })
        .catch(function (error) {
          // handle error
          console.log(error);
        });
    }

  const cheeseHover = function () {
    gsap.to(cheese.current, {
      scale: 1.25,
      ease: "bounce",
    });
  };

  const cheeseHoverLeave = function () {
    gsap.to(cheese.current, {
      scale: 1,
      ease: "bounce",
    });
  };

  const pulseButton = function () {
    setClicked(true);
    gsap.to(button.current, {
      scale: 1.25,
      delay: 1,
      repeat: 10,
      yoyo: true,
    });
  };

  // onClick={() => setClicked(true)}

  return (
    <>
      <div>
        <p
          ref={typing}
          className="absolute typing w-5/6 mt-2 px-2 font-bold flex-1 text-center"
        ></p>
      </div>
      <div className="flex flex-row justify-center items-center h-5/6">
        <div
          ref={robot}
          className="bg-contain bg-center bg-no-repeat flex-1"
          style={verduny}
        ></div>
        <div className="flex-1 text-center">
          {clicked ? (
            <p className="cheeseMessage absolute z-10 bg-white rounded-md p-4 shadow-lg shadow-black">
              "{task}"
            </p>
          ) : null}
          <div
            onMouseEnter={cheeseHover}
            onMouseLeave={cheeseHoverLeave}
            ref={cheese}
            className="cursor-pointer bg-contain bg-center bg-no-repeat"
            style={dip}
            onClick={pulseButton}
          ></div>
        </div>
      </div>
      <div className="text-center">
        <button
          ref={button}
          className="bg-amber-400 hover:bg-amber-500 rounded-md px-5 py-1 shadow-md shadow-black"
        >
          <Link to="/Nordo">Next</Link>
        </button>
      </div>
    </>
  );
}

export default Verduny;
