import React from "react";
import { Link } from "react-router-dom";

function EndPage() {
    
  return (
    <div>
      <h1 className="text-center font-bold h-1/2 mb-11">
        Thank You for visiting Accelerating Poutine Production. <br />
        Hope you enjoyed your stay. <br />
        Have a great day!
      </h1>
      <button>
        <Link to="/Pierre">Restart</Link>
      </button>
    </div>
  );
}

export default EndPage;
