import { gsap } from "gsap";
import { TextPlugin } from "gsap/TextPlugin";
import React, { useRef, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const pierre = {
  backgroundImage: 'url("/images/pierre.png")',
  height: "250px",
  width: "200px",
};
const poutine = {
  backgroundImage: 'url("/images/poutine.png")',
  height: "100px",
  // width: "200px",
};
gsap.registerPlugin(TextPlugin); // registers text-typing animation plugin.

function Pierre() {
  const app = useRef(null); // selects header dom element
  const title = useRef(null); // selects header dom element
  const typing = useRef(null); // selects header dom element
  const robot = useRef(null); // selects header dom element
  const cheese = useRef(null); // selects header dom element
  const button = useRef(null); // selects header dom element
  // Declare a new state variable, which we'll call "clicked"
  const [clicked, setClicked] = useState(false);
  const [task, setTask] = useState("");

  // animations - manual DOM manipulations
  useEffect(() => {
    gsap.from(app.current, { opacity: 0, duration: 1 });
    gsap.from(title.current, {
      scale: 100,
      opacity: 0,
      delay: 1,
    });
    gsap.from(robot.current, { scale: 0, opacity: 0, delay: 2, ease: "back" });
    gsap.from(cheese.current, {
      y: -100,
      opacity: 0,
      delay: 3,
      ease: "bounce",
    });

    gsap.to(typing.current, {
      text: "Hi, I'm Pierre. I'll be mixing the ingredients in cardboard, and sending the poutine box to the user! Click the poutine below. Then click Next.",
      delay: 5,
      duration: 4,
      ease: "none",
    });
    gsap.from(button.current, {
      scale: 0,
      opacity: 0,
      delay: 10,
      duration: 2,
      ease: "back",
    });

    PierreAPI();
  }, [title]);

  function PierreAPI() {
    axios
      .get("https://api.jsonserve.com/R9AiIw")
      .then(function (response) {
        // handle success
        console.log(response);
        const PierreTask = response.data.Robot.Pierre.task;
        setTask(PierreTask);
      })
      .catch(function (error) {
        // handle error
        console.log(error);
      });
  }

  const cheeseHover = function () {
    gsap.to(cheese.current, {
      scale: 1.25,
      ease: "bounce",
    });
  };

  const cheeseHoverLeave = function () {
    gsap.to(cheese.current, {
      scale: 1,
      ease: "bounce",
    });
  };

  const pulseButton = function () {
    setClicked(true);
    gsap.to(button.current, {
      scale: 1.25,
      delay: 1,
      repeat: 10,
      yoyo: true,
    });
  };

  // onClick={() => setClicked(true)}

  return (
    <>
      <div>
        <p
          ref={typing}
          className="absolute typing w-5/6 mt-2 px-2 font-bold flex-1 text-center"
        ></p>
      </div>
      <div className="flex flex-row justify-center items-center h-5/6">
        <div
          ref={robot}
          className="bg-contain bg-center bg-no-repeat flex-1"
          style={pierre}
        ></div>
        <div className="flex-1 text-center">
          {clicked ? (
            <p className="cheeseMessage absolute z-10 bg-white rounded-md p-4 shadow-lg shadow-black">
              "{task}"
            </p>
          ) : null}
          <div
            onMouseEnter={cheeseHover}
            onMouseLeave={cheeseHoverLeave}
            ref={cheese}
            className="cursor-pointer bg-contain bg-center bg-no-repeat"
            style={poutine}
            onClick={pulseButton}
          ></div>
        </div>
      </div>
      <div className="text-center">
        <button
          ref={button}
          className="bg-amber-400 hover:bg-amber-500 rounded-md px-5 py-1 shadow-md shadow-black"
        >
          <Link to="/EndPage">Next</Link>
        </button>
      </div>
    </>
  );
}

export default Pierre;
