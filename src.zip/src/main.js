import { gsap } from "gsap";
import React, { useRef, useEffect } from "react";
// import { TextPlugin } from "gsap/TextPlugin";
import { Outlet } from "react-router-dom";

const backImg = {
  backgroundImage: 'url("/images/restoBackground.jpg")',
  height: "87vh",
};
const bakeryPattern = {
  backgroundImage: 'url("/images/bakery-pattern.png")',
  height: "87vh",
};

function Main() {
  const app = useRef(null); // selects header dom element
  const title = useRef(null); // selects header dom element

  //  Animation's - fade in on first loading screen and title zooming from large to small
  useEffect(() => {
    gsap.from(app.current, { opacity: 0, duration: 1 });
    gsap.from(title.current, {
      scale: 100,
      opacity: 0,
      delay: 1,
    });
  }, [title]);

  return (
    <div ref={app} className="App">
      {/* Header Section */}
      <div className="bg-gradient-to-r from-amber-500 to-amber-300	">
        <div className="container mx-auto p-6 text-center text-white">
          <h1 ref={title} className="title text-3xl font-bold">
            Accelerating Poutine Production
          </h1>
        </div>
      </div>
      {/* main section and background of main section */}
      <div className="relative">
        <div className="bg-cover bg-center bg-no-repeat" style={backImg}></div>
        <div className="absolute top-0 left-0 h-full w-full bg-yellow-900/75 bg-cover flex items-center">
          <div className="container w-5/6 lg:w-2/4 h-4/6 sm:h-5/6 bg-white/70 rounded-lg shadow-xl shadow-black">
            <div className="absolute overflow-hidden w-5/6 lg:w-2/4 h-4/6 sm:h-5/6">
              <div
                className="opacity-5 bg-cover bg-center bg-no-repeat"
                style={bakeryPattern}
              ></div>
            </div>
            {/* output robot components here */}
            <Outlet />
          </div>
        </div>
      </div>

      {/* Footer Section */}
      <div className="bg-neutral-800 h-52">
        <div className="container mx-auto p-6 text-center text-white">
          <p className="mt-5 drop-shadow-md shadow-black">
            Welcome to Accelerating Poutine Production
          </p>
          <p>Enjoy your meal! :)</p>
          <p>Thank you for visiting </p>
          <a
            href="https://github.com/levarowoyemi/Accelerating-Poutine-Production"
            target="_blank"
            rel="noreferrer"
          >
            <img
              className="github-logo"
              src="./images/github-logo.png"
              alt="github-logo"
            />
          </a>

          {/* <p className="mt-5 text-sm"><a href='https://www.freepik.com/vectors/design'>Design vector created by freepik - www.freepik.com</a></p> */}
          {/* <a href="https://www.flaticon.com/free-icons/cat" title="cat icons">Cat icons created by Dave Gandy - Flaticon</a> */}
        </div>
      </div>
    </div>
  );
}

export default Main;
