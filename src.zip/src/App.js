import { BrowserRouter, Routes, Route } from "react-router-dom";
import Main from "./main";
import Outremona from "./components/Outremona";
import Montroyashi from "./components/Montroyashi";
import Verduny from "./components/Verduny";
import Nordo from "./components/Nordo";
import Bizar from "./components/Bizar";
import Oldoporto from "./components/Oldoporto";
import Pierre from "./components/Pierre";
import EndPage from "./components/EndPage";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Main />}>
          <Route index element={<Outremona />} />
          <Route path="Montroyashi" element={<Montroyashi />} />
          <Route path="Verduny" element={<Verduny />} />
          <Route path="Nordo" element={<Nordo />} />
          <Route path="Bizar" element={<Bizar />} />
          <Route path="Oldoporto" element={<Oldoporto />} />
          <Route path="Pierre" element={<Pierre />} />
          <Route path="EndPage" element={<EndPage />} />
          <Route
            path="*"
            element={
              <main style={{ padding: "1rem" }}>
                <p>There's nothing here! Please Refresh to start again!</p>
              </main>
            }
          />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
